
<link rel="shortcut icon" href="<?php echo base_url();?>assets/global/item_thumb.png">

<link href="<?php echo site_url('assets/backend/plugins/bootstrap-select2/select2.css');?>" rel="stylesheet" type="text/css" media="screen" />
<link href="<?php echo site_url('assets/backend/plugins/jquery-datatable/css/jquery.dataTables.css');?>" rel="stylesheet" type="text/css" />
<link href="<?php echo site_url('assets/backend/plugins/datatables-responsive/css/datatables.responsive.css');?>" rel="stylesheet" type="text/css" media="screen" />

<!-- BEGIN PLUGIN CSS -->
<link href="<?php echo site_url('assets/backend/plugins/pace/pace-theme-flash.css');?>" rel="stylesheet" type="text/css" media="screen" />
<link href="<?php echo site_url('assets/backend/plugins/bootstrapv3/css/bootstrap.min.css');?>" rel="stylesheet" type="text/css" />
<link href="<?php echo site_url('assets/backend/plugins/bootstrapv3/css/bootstrap-theme.min.css');?>" rel="stylesheet" type="text/css" />
<link href="<?php echo site_url('assets/backend/plugins/font-awesome/css/font-awesome.css');?>" rel="stylesheet" type="text/css" />
<link href="<?php echo site_url('assets/backend/plugins/animate.min.css');?>" rel="stylesheet" type="text/css" />
<link href="<?php echo site_url('assets/backend/plugins/jquery-scrollbar/jquery.scrollbar.css');?>" rel="stylesheet" type="text/css" />
<!-- END PLUGIN CSS -->
<!-- BEGIN CORE CSS FRAMEWORK -->
<link href="<?php echo site_url('assets/backend/css/icon.css');?>" rel="stylesheet">
<link href="<?php echo site_url('assets/backend/webarch/css/webarch.css');?>" rel="stylesheet" type="text/css" />
<!-- END CORE CSS FRAMEWORK -->