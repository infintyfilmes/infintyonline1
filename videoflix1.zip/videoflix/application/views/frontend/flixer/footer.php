<footer>
	<div class="row">
		<div class="col-lg-12">
			<ul class="list-unstyled">
				<li><a href="<?php echo base_url();?>index.php?general/faq">Faq</a></li>
				<li><a href="<?php echo base_url();?>index.php?general/privacypolicy">Privacy Policy</a></li>
				<li><a href="<?php echo base_url();?>index.php?general/refundpolicy">Refund Policy</a></li>
			</ul>
			<p>Made with <i class="fa fa-heart"></i> by <a href="http://vmax-studio.com/" rel="nofollow">Vmax-Studio</a>. Contact us at <a href="mailto:vmaxstudio15@gmail.com">vmaxstudio15@gmail.com</a>.</p>
		</div>
	</div>
</footer>