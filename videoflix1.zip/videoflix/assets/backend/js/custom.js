// Custom js 
// Author : Vmax Studio

$(document).ready(function(){
	
  //Dropdown menu - select2 plug-in
  $(".select2").select2();
});

